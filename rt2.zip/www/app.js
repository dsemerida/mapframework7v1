require.config({
	paths: {
		handlebars: "scripts/handlebars",
		text: "scripts/text",
		hbs: "scripts/hbs"
        
	},
	shim: {
		handlebars: {
			exports: "Handlebars"
		}
	}
});


function validclearcache(callback)
{
    var loged = validLocalStorage(localStorage.getItem("gid"));
        if (!loged) {
            apcopy.f7.closePanel();
            clearSession();
            setTimeout(function(){
                apcopy.mainView.loadPage("index.html");
            },500);
         
        }else
        {
            callback();      
        }
        
}



// valid if property on localstorage exist
function validLocalStorage(lstore) {
    var localStorage = lstore;
    var loged = true;
    if (!localStorage || localStorage == null || localStorage=="null")
        return  false;
    if (localStorage.length == 0) {
        return false;
    }
    return true;
}






 function closeSs() {
        var gd = localStorage.getItem("gid");
        close = true;
        cp = 0;
        validclearcache(function(){
            $$.ajax({
                    method: "POST",
                    url: apcopy.t.hostserver + "LoginManager/Postclose?guid=" + gd,
                    //ata:gd,
                    success: function (response) {
                        var i = jQuery.parseJSON(response);
                        localStorage.setItem("gid", "")
                        localStorage.setItem("isinv", "");
                        localStorage.setItem("settings", "");
                        apcopy.f7.closePanel();
                        apcopy.mainView.loadPage("index.html");
                    },
                    error: function (error) {
                        clearSession();
                        
                    }
                });
        });
        
        
    }

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function abrirweb(){
    var $target=$(this);
    var link=$target.attr("link");
    inapp.openwebpage(link);
}


   

  


     /// valid if strings contains some word
    function contains(from, st) { 
       var has = from.indexOf(st) > -1;
       return has;
    }

     /// Load href of website official on menu
    function customWebsite() { 
       
         var $ws = $(".wsof");
         var getss = localStorage.getItem("settings");
         if (getss)
         {
             var settings = JSON.parse(getss);
             $ws.on("click", function () {
                cordova.InAppBrowser.open(settings.webPrincipal, "_blank", "location=true");
             });
         }
        
    }
    


var hostserver = "";
var htserverlte = "";

var waspulling = false;
var settings = {};

function clearSession(app) { 
    localStorage.setItem("gid", "")
    localStorage.setItem("isinv", "");
  
    //window.open("pages/index.html");
}


define('app', ['scripts/router', 'scripts/app/controllers/templateController', 'scripts/utils'], function (Router, tm,utils) {
    Router.init();
        
    $(".expirationform").keypress(function(){
        var $sender = $(this);
        console.log($sender.val());
    });

    
  
    var f7 = new Framework7({
        modalTitle: 'Marchant',
        // Enable Material theme
        material: true,
        swipeBackPage: false,
        pushState: true,
        pushStateOnLoad: false
    });


    function removebaner() {
        $(".banner").remove();
        $(".multimedia").css("height", "72%");
        $(".contenedor").css("height", "80%");
        $(".contendor-searchbar").css("margin-top", "16%");
        $(".search-forms").css("margin-top", "16%");
        $(".search-form-operation").css("margin-top", "20%");
    }

    function getexpiration(){
       var expiration= $("#expirationdate").val();
        var expires= expiration.split("/");
        var expijson={
            mont:expires[0],
            year:expires[1]
        };
        return expijson;
    }

    function clearknet(){
        $(".clear-knet").val("");
    }

    /// validate from cards to set server
    function validate_knety(errMessage){
         var form = f7.formToJSON('#knet-form');
        var message = "";
        if (form.card.length == 0) {
            errMessage.text = "No. tarjeta requerida";
            return false;
        } else 
        {
            if(!Conekta.card.validateNumber(form.card))
            {
                errMessage.text = "No. tarjeta invalida";
                return false;
            }
        }
        

        if (form.name.length == 0) {
            errMessage.text = "Nombre tarjetahabiente requerido";
            return false;
        }

        if(form.expirationmont.length==0)
        {
            errMessage.text = "Mes de expiración requerido";
            return false;
        }

        if(form.expirationyear.length==0)
        {
            errMessage.text = "Año de expiración requerido";
            return false;
        }

        if(!Conekta.card.validateExpirationDate(form.expirationmont, form.expirationyear))
        {
            errMessage.text = "La fecha de expiración es invalida";
            return false;
        }
        if (form.cvc.length == 0) {
            errMessage.text = "CVC requerido";
            return false;
        }
        else {
            if(!Conekta.card.validateCVC(form.cvc))
            {
                errMessage.text = "CVC incorrecto";
                return false;
            }
        }


         if (form.email.length == 0) {
            errMessage.text = "Email requerido";
            return false;
        }
        else {
            if (!utils.validateEmail(form.email)) {
                errMessage.text = "Email incorrecto";
                return false;
            }

        }
        if (form.phone.length == 0) {
            errMessage.text = "Teléfono requerido";
            return false;
        }
         if (form.street.length == 0) {
            errMessage.text = "Calle requerida";
            return false;
        }
        if (form.Colonia.length == 0) {
            errMessage.text = "Colonia requerida";
            return false;
        }
        if (form.city.length == 0) {
            errMessage.text = "Ciudad requerida";
            return false;
        }
        if (form.state.length == 0) {
            errMessage.text = "Estado requerida";
            return false;
        }
         if (form.country.length == 0) {
            errMessage.text = "Estado requerida";
            return false;
        }
        return true;
    }

   

    
    function kneterror(err){
        f7.hidePreloader();
        f7.alert(err.message_to_purchaser);
    }
    var kentcopy={};
 
    // Expose Internal DOM library
    var $$ = Dom7;

    // Add main view
    var mainView = f7.addView('.view-main', {
    });

    var $$ = Framework7.$;



    

    function restrinctions(callback){
        var exist= existon(localStorage.getItem("readText"));
        if(!exist)
        {
            callback();
        }
        else
        {
            f7.alert('Debe de confirmar de recibido.');
        }
    }
    function backEvent(href){
        console.log("BACK CALLED");
        restrinctions(function(){
            var link = href ? "pages/" + href : "pages/welcome.html";
            mainView.loadPage(link);
        });
        
        
    }

   

    

    function eventMenu()
    {
        $(".openmenu").on("click",function(){

            restrinctions(function(){
                f7.openPanel("left");
            });
        });

    }


    
    var tools = {
        /// this section is when we can close sesion
        initUI: function () {
            

            
           
                


                //return true;
            
        },
        hostserver: hostserver,
        htserverlte: htserverlte
    };


    var getErrorAjax = function (error) {
           closeSs();
    }

    function message(text) {
        f7.alert(text, "Mercaditoapp");
    }

    function existon(lstore) {
        var localStorage = lstore;
        var loged = true;
        if (!localStorage || localStorage == null)
            return  false;
        if (localStorage.length == 0) {
            return false;
        }
        return true;
    }

    function getUsSesion(){
       return jQuery.parseJSON(localStorage.getItem("gid"));
    }
    
    function getRes(tk){
        return jQuery.parseJSON(tk);
    }

    apcopy = {
        f7: f7,
        mainView: mainView,
        router: Router,
        t: tools,
        notification: message,
        template: tm,
        errorAjax:getErrorAjax,
        log:getUsSesion,
        getRes:getRes


    };
    

    return apcopy;
});