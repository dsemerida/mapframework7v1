define(["app", "scripts/utils"], function (app, utils) {
    var query = {}, refresh = false;

    

    function handlersStepsLocal(){
        
         // Define a div tag with id="map_canvas"
          var mapDiv = document.getElementById("mapi");

          // Initialize the map plugin
          var map = plugin.google.maps.Map.getMap(mapDiv);

          // The MAP_READY event notifies the native map view is fully ready to use.
          map.one(plugin.google.maps.event.MAP_READY, function(){});
     /* var  map = new google.maps.Map(document.getElementById('mapLocal'), {
                            center: {lat: 20.9920106, lng: -89.639286},
                            zoom: 12,
                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                            mapTypeControl: false,
                            disableDefaultUI: true,
                            zoomControl:true,
                           
                            gestureHandling: "greedy"
                        });*/
        
        
    }

    
    //var $itemscategory=$(".itemscategory");
    function handlers(){
        handlersStepsLocal();
        
    }

    function init(q) {
        query = q;
        app.t.initUI();
        handlers();
        
    }



    return {
        init: init
    };
});