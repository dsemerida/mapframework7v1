define(["app"], function (app,reguser) {
      
	function init(query) {
        
        var gd = localStorage.getItem("gid");
        if (gd && gd.length > 0){
            app.mainView.loadPage("pages/welcome.html");
        }
	}


    
    
    function loadHandlers() {
       // app.t.resetUI();

       $(".regus").on("click",function(){
            app.f7.popup(".ppRegUs1");
       });  

        $(".recovery_cancel").on("click",function(){
            $(".clear-email").val("");
            app.f7.closeModal('.recovery');
        });

    }

    function init(query) {
        var gd = localStorage.getItem("gid");
        if (gd && gd.length > 0){
            app.mainView.loadPage("pages/welcome.html");
        }
        close = false;
        loadHandlers();
        reguser.init();
	}

	return {
		init: init
	};




});