define(["app","scripts/utils.js"], function (app,utils) {
    var click=false;
    
    function getUsSesion(){
       return jQuery.parseJSON(localStorage.getItem("usreg"));
    }

    function resetUsSesion(us){
        localStorage.setItem("usreg",JSON.stringify(us))
    }

    function afteremail()
    {
        var us=getUsSesion();
        us.Email=$("#txtemailreg").val();
        resetUsSesion(us);
        app.f7.closeModal(".ppRegUs3");
        app.f7.popup(".ppRegUs4");
    }
    function afterphone()
    {
            var us=getUsSesion();
            us.UserName=$("#txtcelRegus").val();
            resetUsSesion(us);
            app.f7.closeModal(".ppRegUs1");
            app.f7.popup(".ppRegUs2");
    }
    function firsstep(isemail,callback){
        var url="",mensaje="";
        if(!isemail){
            mensaje="Existe un usuario con el número que desea ingresar.";
            url=app.t.hostserver + "users/any?u="+$("#txtcelRegus").val()+"&em=0";
        }
        else{
            mensaje="Existe un usuario con el correo que desea ingresar.";
            url= app.t.hostserver + "users/any?u=0&em="+$("#txtemailreg").val()
        }
        $$.ajax({
                        method: "POST",
                        url: url,
                        success: function (response) {
                            var i = jQuery.parseJSON(response);
                            app.f7.hidePreloader();
                            if(i)
                            {
                                app.f7.alert(mensaje);
                                return;
                            }
                            callback();
                            /// call load credentials of settings and redirect to welcome page
                            //firstloadCredential();
                            //app.mainView.loadPage("pages/clientside.html");
                        },
                        error: function (error) {
                            
                        }
                    });
    }
    function finregus()
    {
        
        

        $$.ajax({
            method: "POST",
            url: app.t.hostserver + "users/adduser",
            data: getUsSesion(),
            success: function (response) {
                var i = jQuery.parseJSON(response);
                localStorage.setItem("gid", response);
                app.f7.hidePreloader();
                initusreg();
                app.f7.alert('Bienvenido', function () {
                    $(".clearreg").val("");
                    app.f7.closeModal(".ppRegUs4");
                    app.mainView.loadPage("pages/clientside.html");
                });
                /// call load credentials of settings and redirect to welcome page
                //firstloadCredential();
                //app.mainView.loadPage("pages/clientside.html");
            },
            error: function (error) {
                app.f7.hidePreloader();
                if(error.status===404)
                {
                   app.notification("Usuario o Password incorrecto.");
                }
                else if(error.status===502)
                {
                    app.notification("Intente con otro usuario.");
                }

            }
        });
    }
    function handlers(){
        $(".unclick").off();
        $(".bkindex").on("click",function(){
            $(".clearreg").val("");
            initusreg();
            app.f7.closeModal(".ppRegUs1");
            app.mainView.loadPage("index.html");
        });
        $(".backrus2").on("click",function(){
            app.f7.closeModal(".ppRegUs3");
            app.f7.popup(".ppRegUs2");
        });
        $(".backrus3").on("click",function(){
            app.f7.closeModal(".ppRegUs4");
            app.f7.popup(".ppRegUs3");
        });
        $(".backrus4").on("click",function(){
            app.f7.closeModal(".ppRegUs4");
            app.f7.popup(".ppRegUs3");
        });
        
        $(".closeppRegUs2").on("click",function(){
            app.f7.closeModal(".ppRegUs2");
            app.f7.popup(".ppRegUs1");
        });

        $(".clickRegUs1").on("click",function(){
            var cel=$("#txtcelRegus").val();
            if(cel.length==0)
            {
                app.f7.alert("Indica el No. de Celular");
            }
            else
            {
                if(cel.length < 10 || cel.length > 10){
                    app.f7.alert("Extensión mínima de 10 caracteres.");
                }
                else{
                   if(!utils.phonenumber(cel))
                   {
                        app.f7.alert("Número incorrecto.");
                        return;
                   }
                   app.f7.showPreloader("");
                   setTimeout(function(){
                     firsstep(false,afterphone);
                   },2000);
                   
                }
                
            }
        });

        $(".clickRegUs2").on("click",function(){
           
            var us=getUsSesion();
            us.FullName=$("#txtnamereg").val()+" "+$("#txtlastreg").val();
            resetUsSesion(us);
            app.f7.closeModal(".ppRegUs2");
           
            app.f7.popup(".ppRegUs3");
        });

        $(".clickRegUs3").on("click",function(){
            
            var us=getUsSesion();
            var email=$("#txtemailreg").val();
            var confirm=$("#txtconfirmarreg").val();
            if(!utils.validateEmail(email))
            {
                app.f7.alert("Correo electrónico inválido");
                return;
            }
            if(!utils.validateEmail(confirm))
            {
                app.f7.alert("Confirmar Correo inválido");
                return;
            }
            if(confirm==email)
            {
                app.f7.showPreloader("");
                setTimeout(function(){
                    firsstep(true,afteremail);
                },2000);
                
                
            }
            else
            {
                
                app.f7.alert("El correo electrónico no coindice");
            }
            
        });
        

        $(".finregus").on("click",function(){
            app.f7.showPreloader("");
            setTimeout(finregus, 2000);
        });

    }

    function initusreg()
    {
        var usreg={
            Device:1,
            Type:2,
            FullName:"",
            Email:"",
            UserName:"",
            Password:""
        }
        localStorage.setItem("usreg",JSON.stringify(usreg));
    }
    function init(query) {
        console.log("DONE");
        initusreg();
        handlers();
    }

    return {
        init: init
    };
});